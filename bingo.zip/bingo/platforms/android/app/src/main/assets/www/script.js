// Arquivo: script.js

// Inicia o jogo selecionado
function startGame(game) {
    alert(`Iniciando o jogo: ${game}`);
    // Aqui você redirecionaria para a página do jogo correspondente
    window.location.href = `${game}.html`; // Ex.: caça-palavras.html
}

// Seleciona o modo de jogo
function selectMode(mode) {
    alert(`Você escolheu jogar: ${mode === 'amigos' ? 'com amigos' : 'contra o robô'}`);
    // Dependendo do modo, você pode configurar o multiplayer ou inteligência artificial
}
