const cells = document.querySelectorAll('[data-cell]');
const restartButton = document.getElementById('restartButton');
const chooseX = document.getElementById('chooseX');
const chooseO = document.getElementById('chooseO');
const gameContainer = document.getElementById('game-container');
const playerSelection = document.getElementById('player-selection');

let isCircleTurn = false; // Define o turno inicial
let currentPlayer = ''; // Define o jogador atual

// Define a cor de fundo do site com base no jogador atual
function setSiteColor(player) {
    if (player === 'x') {
        document.body.style.backgroundColor = '#ffebee'; // Vermelho claro
    } else {
        document.body.style.backgroundColor = '#e3f2fd'; // Azul claro
    }
}

// Inicia o jogo com o jogador escolhido
function startGame(player) {
    currentPlayer = player; // Define o jogador inicial
    isCircleTurn = player === 'o'; // Define se é a vez do O
    setSiteColor(currentPlayer); // Aplica a cor inicial
    gameContainer.style.display = 'block'; // Mostra o jogo
    playerSelection.style.display = 'none'; // Esconde a seleção
    resetBoard(); // Reinicia o tabuleiro
}

// Lida com o clique na célula
function handleClick(e) {
    const cell = e.target;
    const currentClass = isCircleTurn ? 'o' : 'x';
    if (!cell.classList.contains('X (vermelho)') && !cell.classList.contains('O (azul)')) {
        placeMark(cell, currentClass); // Adiciona o símbolo do jogador
        if (checkWin(currentClass)) {
            setTimeout(() => alert(`O jogador ${currentClass.toUpperCase()} venceu!`), 100);
            resetBoard(); // Reinicia após vitória
        } else if (isDraw()) {
            setTimeout(() => alert('Deu velha! Empate!'), 100);
            resetBoard(); // Reinicia após empate
        } else {
            swapTurns(); // Alterna os turnos
        }
    }
}

// Coloca o X ou O na célula
function placeMark(cell, currentClass) {
    cell.classList.add(currentClass); // Aplica a classe para estilizar X ou O
    cell.textContent = currentClass.toUpperCase(); // Adiciona o símbolo visualmente
}

// Alterna os turnos e muda a cor do site
function swapTurns() {
    isCircleTurn = !isCircleTurn;
    currentPlayer = isCircleTurn ? 'o' : 'x';
    setSiteColor(currentPlayer);
}

// Verifica se houve vitória
function checkWin(currentClass) {
    const winningCombinations = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    return winningCombinations.some(combination => {
        return combination.every(index => {
            return cells[index].classList.contains(currentClass);
        });
    });
}

// Verifica se houve empate
function isDraw() {
    return [...cells].every(cell => {
        return cell.classList.contains('x') || cell.classList.contains('o');
    });
}

// Reinicia o tabuleiro
function resetBoard() {
    cells.forEach(cell => {
        cell.classList.remove('x', 'o'); // Remove as classes
        cell.textContent = ''; // Limpa o conteúdo da célula
        cell.removeEventListener('click', handleClick); // Remove eventos antigos
        cell.addEventListener('click', handleClick, { once: true }); // Adiciona evento de clique
    });
    setSiteColor(currentPlayer); // Restaura a cor do jogador atual
}

// Configura os eventos
chooseX.addEventListener('click', () => startGame('x'));
chooseO.addEventListener('click', () => startGame('o'));
restartButton.addEventListener('click', resetBoard);

// Inicializa o jogo com a seleção do jogador
resetBoard();
