// Elementos principais da interface
const bingoCard = document.getElementById("bingo-card");
const drawButton = document.getElementById("draw-button");
const restartButton = document.getElementById("restart-button");
const newCardButton = document.getElementById("new-card-button");
const currentNumber = document.getElementById("current-number");

// Variáveis de estado
let drawnNumbers = []; // Números sorteados
let selectedNumbers = new Set(); // Números marcados
let bingoNumbers = {}; // Números organizados por colunas

// Gera os números do bingo organizados por colunas
function generateBingoCard() {
    bingoNumbers = {
        B: generateUniqueNumbers(1, 15, 5),
        I: generateUniqueNumbers(16, 30, 5),
        N: generateUniqueNumbers(31, 45, 5),
        G: generateUniqueNumbers(46, 60, 5),
        O: generateUniqueNumbers(61, 75, 5),
    };

    // Define o espaço "FREE" no centro da cartela
    bingoNumbers.N[2] = "FREE";

    renderBingoCard();
}

// Gera números únicos dentro de um intervalo
function generateUniqueNumbers(min, max, count) {
    const numbers = [];
    while (numbers.length < count) {
        const num = Math.floor(Math.random() * (max - min + 1)) + min;
        if (!numbers.includes(num)) {
            numbers.push(num);
        }
    }
    return numbers.sort((a, b) => a - b); // Ordena os números
}

// Renderiza a cartela de bingo na tela
function renderBingoCard() {
    bingoCard.innerHTML = ''; // Limpa a cartela existente

    for (let row = 0; row < 5; row++) {
        ['B', 'I', 'N', 'G', 'O'].forEach((letter) => {
            const cell = document.createElement("div");
            cell.classList.add("bingo-cell");

            // Espaço central "FREE" com imagem
            if (letter === 'N' && row === 2) {
                cell.classList.add("free");
                const img = document.createElement("img");
                img.src = 'img/anadoidona.png'; // Caminho da sua imagem
                img.alt = "Espaço Livre";
                img.style.width = '100%';
                img.style.height = '100%';
                img.style.objectFit = 'cover';
                cell.appendChild(img);
            } else {
                const num = bingoNumbers[letter][row];
                cell.textContent = num;
                cell.dataset.number = num; // Atribui o número para facilitar a identificação

                // Clique para marcar o número, se sorteado
                cell.addEventListener("click", () => {
                    if (drawnNumbers.includes(num)) {
                        markNumber(cell, num);
                    } else {
                        alert("Este número ainda não foi sorteado.");
                    }
                });
            }

            bingoCard.appendChild(cell);
        });
    }
}

// Marca automaticamente os números sorteados na cartela
function markDrawnNumbersAutomatically() {
    document.querySelectorAll(".bingo-cell").forEach((cell) => {
        const num = parseInt(cell.dataset.number); // Obtém o número da célula
        if (drawnNumbers.includes(num) && !cell.classList.contains("selected")) {
            cell.classList.add("selected");
            selectedNumbers.add(num); // Adiciona aos números marcados
        }
    });
}

// Marca um número na cartela quando clicado
function markNumber(cell, num) {
    if (selectedNumbers.has(num)) return; // Ignora se já estiver marcado
    cell.classList.add("selected");
    selectedNumbers.add(num);
}

// Sorteia um número aleatório e o exibe
function drawNumber() {
    const availableNumbers = [];
    for (let i = 1; i <= 75; i++) {
        if (!drawnNumbers.includes(i)) {
            availableNumbers.push(i);
        }
    }

    if (availableNumbers.length === 0) {
        currentNumber.textContent = "Todos os números foram sorteados!";
        return;
    }

    const drawnNumber = availableNumbers[Math.floor(Math.random() * availableNumbers.length)];
    drawnNumbers.push(drawnNumber);
    currentNumber.textContent = `Número sorteado: ${drawnNumber}`;
    markDrawnNumbersAutomatically(); // Marca automaticamente na cartela
}

// Função para trocar a cartela e reiniciar os números sorteados
function restartWithNewCard() {
    selectedNumbers.clear(); // Limpa números marcados
    drawnNumbers = []; // Reinicia os números sorteados
    currentNumber.textContent = "Número sorteado:"; // Reinicia o display
    generateBingoCard(); // Gera uma nova cartela
}

// Função para reiniciar o jogo completamente (sem nova cartela)
function restartGameFully() {
    selectedNumbers.clear(); // Limpa números marcados
    drawnNumbers = []; // Reinicia os números sorteados
    currentNumber.textContent = "Número sorteado:";
    renderBingoCard(); // Re-renderiza a cartela atual
}

// Adiciona eventos aos botões
drawButton.addEventListener("click", drawNumber); // Sorteia um número
restartButton.addEventListener("click", restartGameFully); // Reinicia o jogo com a mesma cartela
newCardButton.addEventListener("click", restartWithNewCard); // Troca de cartela e reinicia tudo

// Inicializa o jogo ao carregar
generateBingoCard();
