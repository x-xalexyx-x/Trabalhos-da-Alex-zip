const gameBoard = document.getElementById("game-board");
const attemptCounter = document.getElementById("attempt-counter");
const timerDisplay = document.getElementById("timer-display");
const restartButton = document.getElementById("restart-button");
const overlay = document.getElementById("overlay");
const overlayMessage = document.getElementById("overlay-message");

// Sons
const matchSound = new Audio("musica/acerto.wav");
const errorSound = new Audio("musica/erro.wav");
const winSound = new Audio("musica/vitoria.mp3");

// Lista de Emojis dos Animais
const animalEmojis = [
    "🐶", "🐶", "🐱", "🐱", "🐭", "🐭", "🐹", "🐹",
    "🐰", "🐰", "🦊", "🦊", "🐻", "🐻", "🐼", "🐼",
    "🐨", "🐨", "🐯", "🐯", "🦁", "🦁", "🐮", "🐮",
    "🐷", "🐷", "🐸", "🐸", "🐵", "🐵", "🐔", "🐔"
];

let firstCard = null;
let secondCard = null;
let lockBoard = false;
let matchedPairs = 0;
let attempts = 0;
let timer = 0;
let timerInterval = null;
let gameStarted = false;

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function createCards() {
    gameBoard.innerHTML = "";
    shuffle(animalEmojis);
    animalEmojis.forEach(emoji => {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.emoji = emoji;
        card.addEventListener("click", () => handleCardClick(card));
        gameBoard.appendChild(card);
    });

    firstCard = null;
    secondCard = null;
    lockBoard = false;
    matchedPairs = 0;
    attempts = 0;
    attemptCounter.textContent = "Tentativas: 0";
    
    timer = 0;
    gameStarted = false;
    clearInterval(timerInterval);
    timerDisplay.textContent = "Tempo: 0s";
    
    overlay.style.display = "none"; // Esconde a tela de finalização ao reiniciar
}

function startTimer() {
    gameStarted = true;
    timerInterval = setInterval(() => {
        timer++;
        timerDisplay.textContent = `Tempo: ${timer}s`;
    }, 1000);
}

function playSound(sound) {
    sound.currentTime = 0; // Reseta o áudio antes de tocar
    sound.play();
}

function handleCardClick(card) {
    if (lockBoard || card === firstCard || card.classList.contains("matched")) return;

    if (!gameStarted) startTimer();

    card.textContent = card.dataset.emoji;
    card.classList.add("flipped");

    if (!firstCard) {
        firstCard = card;
        return;
    }

    secondCard = card;
    attempts++;
    attemptCounter.textContent = `Tentativas: ${attempts}`;
    checkMatch();
}

function checkMatch() {
    lockBoard = true;

    if (firstCard.dataset.emoji === secondCard.dataset.emoji) {
        playSound(matchSound); // Som de acerto
        firstCard.classList.add("matched");
        secondCard.classList.add("matched");
        matchedPairs++;

        resetBoard();

        if (matchedPairs === animalEmojis.length / 2) {
            setTimeout(endGame, 500); // Pequeno atraso para exibir a tela
        }
    } else {
        playSound(errorSound); // Som de erro
        firstCard.classList.add("error");
        secondCard.classList.add("error");

        setTimeout(() => {
            firstCard.classList.remove("flipped", "error");
            secondCard.classList.remove("flipped", "error");
            firstCard.textContent = "";
            secondCard.textContent = "";
            resetBoard();
        }, 1000);
    }
}

function resetBoard() {
    [firstCard, secondCard, lockBoard] = [null, null, false];
}

function endGame() {
    clearInterval(timerInterval);
    playSound(winSound); // Som de vitória

    overlayMessage.innerHTML = `🎉 Parabéns! Você completou em <strong>${timer} segundos</strong> com <strong>${attempts} tentativas</strong>!`;
    overlay.style.display = "flex"; // Mostra a tela de finalização
}

restartButton.addEventListener("click", createCards);

createCards();
