const socket = io();
const form = document.getElementById('form');
const input = document.getElementById('input');
const usernameInput = document.getElementById('username');
const messages = document.getElementById('messages');
let myId = null;

socket.on('connect', () => {
  myId = socket.id;
});

form.addEventListener('submit', function(e) {
  e.preventDefault();
  if (input.value && usernameInput.value) {
    socket.emit('chat message', {
      username: usernameInput.value.trim(),
      text: input.value.trim()
    });
    input.value = '';
  }
});

socket.on('chat message', function(data) {
  const item = document.createElement('li');
  const isSelf = data.id === myId;
  item.className = isSelf ? 'self' : 'other';
  item.textContent = (isSelf ? 'Você' : data.username || 'Outro') + ': ' + data.text;
  messages.appendChild(item);
  messages.scrollTop = messages.scrollHeight;
});
