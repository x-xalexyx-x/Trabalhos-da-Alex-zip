
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('Usuário conectado:', socket.id);

  socket.on('chat message', (msg) => {
    io.emit('chat message', {
      id: socket.id,
      username: msg.username,
      text: msg.text
    });
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado:', socket.id);
  });
});

const PORT = 3000;
http.listen(PORT, () => {
  console.log(`Servidor rodando em http://192.168.137.26:${PORT}`);
});
