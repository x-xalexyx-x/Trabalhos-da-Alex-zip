// Carrinho
let carrinho = [];
let total = 0;

// Adicionar item ao carrinho
function adicionarCarrinho(nome, preco) {
    carrinho.push({ nome, preco });
    total += preco;
    atualizarCarrinho();
}

// Atualizar carrinho na interface
function atualizarCarrinho() {
    const listaCarrinho = document.getElementById('lista-carrinho');
    const totalElemento = document.getElementById('total');

    listaCarrinho.innerHTML = '';

    carrinho.forEach((item, index) => {
        const li = document.createElement('li');
        li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2).replace('.', ',')}`;
        
        const botaoRemover = document.createElement('button');
        botaoRemover.textContent = '❌';
        botaoRemover.onclick = () => removerItem(index);

        li.appendChild(botaoRemover);
        listaCarrinho.appendChild(li);
    });

    totalElemento.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
}

// Remover item do carrinho
function removerItem(index) {
    total -= carrinho[index].preco;
    carrinho.splice(index, 1);
    atualizarCarrinho();
}

// Limpar carrinho
function limparCarrinho() {
    carrinho = [];
    total = 0;
    atualizarCarrinho();
}

// Filtros de categoria
function filtrarCategoria(categoria) {
    const cards = document.querySelectorAll('.card');

    cards.forEach(card => {
        if (categoria === 'todos') {
            card.style.display = 'block';
        } else if (card.classList.contains(categoria)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
