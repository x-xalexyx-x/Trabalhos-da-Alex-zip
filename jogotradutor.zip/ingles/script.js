const words = {
    en: [
        { word: "Apple", correct: "Maçã", options: ["Maçã", "Banana", "Pêra", "Uva"] },
        { word: "Dog", correct: "Cachorro", options: ["Gato", "Cachorro", "Pássaro", "Peixe"] },
        { word: "House", correct: "Casa", options: ["Carro", "Casa", "Janela", "Porta"] },
    ],
    es: [
        { word: "Libro", correct: "Livro", options: ["Caneta", "Livro", "Caderno", "Mesa"] },
        { word: "Gato", correct: "Gato", options: ["Cachorro", "Gato", "Pássaro", "Rato"] },
        { word: "Rojo", correct: "Vermelho", options: ["Azul", "Verde", "Amarelo", "Vermelho"] },
    ],
    fr: [
        { word: "Chat", correct: "Gato", options: ["Cachorro", "Gato", "Pássaro", "Coelho"] },
        { word: "Pomme", correct: "Maçã", options: ["Banana", "Maçã", "Uva", "Melão"] },
        { word: "Maison", correct: "Casa", options: ["Escola", "Casa", "Porta", "Carro"] },
    ]
};

let currentLang = '';
let currentQuestion = 0;
let score = 0;
let currentData = [];
let userAnswers = [];

function startGame(lang) {
    currentLang = lang;
    currentQuestion = 0;
    score = 0;
    userAnswers = [];
    currentData = [...words[lang]];
    shuffleArray(currentData);
    document.getElementById('language-selection').classList.add('hidden');
    document.getElementById('summary').classList.add('hidden');
    document.getElementById('game-area').classList.remove('hidden');
    showQuestion();
}

function showQuestion() {
    const data = currentData[currentQuestion];
    document.getElementById('word').innerText = data.word;
    const optionsContainer = document.getElementById('options');
    optionsContainer.innerHTML = "";
    const shuffled = shuffleArray([...data.options]);
    shuffled.forEach(opt => {
        const btn = document.createElement('button');
        btn.innerText = opt;
        btn.classList.add('option-btn');
        btn.onclick = () => checkAnswer(opt);
        optionsContainer.appendChild(btn);
    });
    document.getElementById('result').innerText = "";
    document.getElementById('score').innerText = `Pontuação: ${score}`;
    document.getElementById('next-btn').disabled = true;
}

function checkAnswer(answer) {
    const data = currentData[currentQuestion];
    const buttons = document.querySelectorAll('.option-btn');
    buttons.forEach(btn => {
        btn.disabled = true;
        if (btn.innerText === data.correct) {
            btn.classList.add('correct');
        } else if (btn.innerText === answer) {
            btn.classList.add('wrong');
        }
    });

    let resultText = '';
    if (answer === data.correct) {
        score++;
        resultText = "✅ Correto!";
    } else {
        resultText = `❌ Errado! Resposta correta: ${data.correct}`;
    }

    document.getElementById('result').innerText = resultText;
    document.getElementById('score').innerText = `Pontuação: ${score}`;
    document.getElementById('next-btn').disabled = false;

    userAnswers.push({
        palavra: data.word,
        suaResposta: answer,
        correta: data.correct,
        acertou: answer === data.correct
    });
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < currentData.length) {
        showQuestion();
    } else {
        showSummary();
    }
}

function showSummary() {
    document.getElementById('game-area').classList.add('hidden');
    const summary = document.getElementById('summary');
    const content = document.getElementById('summary-content');
    content.innerHTML = `<p><strong>Pontuação final:</strong> ${score} / ${currentData.length}</p><ul>` +
        userAnswers.map(res =>
            `<li>
                <strong>${res.palavra}</strong>: 
                sua resposta foi <em>${res.suaResposta}</em> - 
                ${res.acertou ? '✅ Correto' : `❌ Errado (certa: ${res.correta})`}
            </li>`).join('') +
        '</ul>';
    summary.classList.remove('hidden');
}

function restartGame() {
    document.getElementById('summary').classList.add('hidden');
    document.getElementById('language-selection').classList.remove('hidden');
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}
