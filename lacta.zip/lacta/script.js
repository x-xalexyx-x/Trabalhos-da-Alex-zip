function filterCategory(category) {
  const allProducts = document.querySelectorAll('.product-card');
  
  allProducts.forEach(product => {
    if (category === 'todos') {
      product.style.display = 'block';
    } else {
      if (product.classList.contains(category)) {
        product.style.display = 'block';
      } else {
        product.style.display = 'none';
      }
    }
  });
}

function searchProducts() {
  const input = document.getElementById('search').value.toLowerCase();
  const products = document.querySelectorAll('.product-card');

  products.forEach(product => {
    const name = product.getAttribute('data-name').toLowerCase();
    product.style.display = name.includes(input) ? 'block' : 'none';
  });
}

let cart = [];

function addToCart(name, price) {
  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ name, price, quantity: 1 });
  }
  updateCart();
}

function removeFromCart(name) {
  const index = cart.findIndex(item => item.name === name);
  if (index > -1) {
    cart.splice(index, 1);
    updateCart();
  }
}

function updateCart() {
  const cartItems = document.getElementById('cart-items');
  const cartCount = document.getElementById('cart-count');
  const cartTotal = document.getElementById('cart-total');

  cartItems.innerHTML = '';
  let total = 0;
  let itemCount = 0;

  cart.forEach(item => {
    const li = document.createElement('li');
    li.innerHTML = `
      ${item.name} x${item.quantity} - R$ ${(item.price * item.quantity).toFixed(2)}
      <button onclick="removeFromCart('${item.name}')" style="margin-left: 10px; color: red; font-weight: bold; cursor: pointer;">X</button>
    `;
    cartItems.appendChild(li);

    total += item.price * item.quantity;
    itemCount += item.quantity;
  });

  cartTotal.textContent = total.toFixed(2);
  cartCount.textContent = itemCount;
}

function toggleCart() {
  const cartElement = document.getElementById('cart');
  cartElement.style.display = cartElement.style.display === 'block' ? 'none' : 'block';
}
