// Ao carregar a página
window.addEventListener("load", () => {
  mostrarPagina('homenagem');
});

// Alternar páginas
function mostrarPagina(id) {
  document.querySelectorAll('.pagina').forEach(sec => sec.classList.remove('ativa'));
  document.getElementById(id).classList.add('ativa');
}

// Mensagem da Mamãe com cópia
function mostrarMensagem() {
  const input = document.getElementById("mensagemInput").value.trim();
  const mensagemDiv = document.getElementById("mensagemExibida");

  if (input === "") {
    mensagemDiv.innerHTML = "<p style='color: red;'>Por favor, escreva uma mensagem!</p>";
    return;
  }

  const mensagemFinal = `💖 Mensagem para a mamãe:\n\n${input}`;
  mensagemDiv.innerHTML = `
    <p style="background-color:#fff0f5; border-left: 5px solid #ff69b4; padding: 1rem; border-radius: 8px;">
      💖 <strong>Sua mensagem:</strong><br>${input}
    </p>
    <p style="color: green;">Mensagem copiada! Agora é só colar e enviar 💌</p>
  `;

  navigator.clipboard.writeText(mensagemFinal).catch(() => {
    alert("Erro ao copiar a mensagem.");
  });
}

// Jogo da Memória
const emojis = ["👩‍👧", "🌷", "🍰", "💝", "📸", "🫶", "💐", "🍼"];
let cartas = [...emojis, ...emojis];
let embaralhadas = [];
let tabuleiro = document.getElementById("tabuleiro");
let mensagemFinal = document.getElementById("mensagemFinal");

let primeiraCarta = null;
let segundaCarta = null;
let bloqueio = false;
let paresEncontrados = 0;

function embaralharCartas() {
  embaralhadas = cartas
    .map((emoji) => ({ emoji, ordem: Math.random() }))
    .sort((a, b) => a.ordem - b.ordem);
}

function criarTabuleiro() {
  tabuleiro.innerHTML = "";
  embaralhadas.forEach((item, index) => {
    const carta = document.createElement("div");
    carta.classList.add("card");
    carta.dataset.emoji = item.emoji;
    carta.dataset.index = index;
    carta.addEventListener("click", revelarCarta);
    tabuleiro.appendChild(carta);
  });
}

function revelarCarta(e) {
  if (bloqueio) return;
  const carta = e.currentTarget;
  const emoji = carta.dataset.emoji;

  if (carta.classList.contains("revealed") || carta.classList.contains("matched")) return;

  carta.textContent = emoji;
  carta.classList.add("revealed");

  if (!primeiraCarta) {
    primeiraCarta = carta;
  } else {
    segundaCarta = carta;
    bloquearTabuleiro();

    if (primeiraCarta.dataset.emoji === segundaCarta.dataset.emoji) {
      primeiraCarta.classList.add("matched");
      segundaCarta.classList.add("matched");
      desbloquearTabuleiro();
      primeiraCarta = null;
      segundaCarta = null;
      paresEncontrados++;
      if (paresEncontrados === emojis.length) {
        mensagemFinal.textContent = "🎉 Parabéns! Você encontrou todos os pares!";
      }
    } else {
      setTimeout(() => {
        primeiraCarta.textContent = "";
        segundaCarta.textContent = "";
        primeiraCarta.classList.remove("revealed");
        segundaCarta.classList.remove("revealed");
        desbloquearTabuleiro();
        primeiraCarta = null;
        segundaCarta = null;
      }, 1000);
    }
  }
}

function bloquearTabuleiro() {
  bloqueio = true;
}

function desbloquearTabuleiro() {
  bloqueio = false;
}

embaralharCartas();
criarTabuleiro();
