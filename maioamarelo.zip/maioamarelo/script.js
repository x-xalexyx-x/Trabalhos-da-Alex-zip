const respostasCorretas = {
  q1: 'a',
  q2: 'a',
  q3: 'a',
  q4: 'a',
  q5: 'a',
  q6: 'a',
};

let pontuacao = 0;

function verificarResposta(perguntaId, alternativa) {
  const respostaCorreta = respostasCorretas[perguntaId];
  const respostaElemento = document.getElementById(`respostaQuiz_${perguntaId}`);
  const botoes = document.querySelectorAll(`#pergunta_${perguntaId} button`);

  if (respostaElemento.dataset.respondido === "true") {
    return; // Já respondido, não permite mudança
  }

  if (alternativa === respostaCorreta) {
    respostaElemento.textContent = "Resposta correta!";
    respostaElemento.classList.remove("errado");
    pontuacao++;
  } else {
    respostaElemento.textContent = "Resposta incorreta!";
    respostaElemento.classList.add("errado");
  }

  // Desabilita todos os botões da pergunta após resposta
  botoes.forEach(btn => btn.disabled = true);

  respostaElemento.dataset.respondido = "true";

  atualizarPontuacao();
}

function atualizarPontuacao() {
  const pontuacaoElemento = document.getElementById("pontuacao");
  pontuacaoElemento.textContent = `Pontuação: ${pontuacao} / 6`;
}

function reiniciarQuiz() {
  pontuacao = 0;
  atualizarPontuacao();

  for (const perguntaId in respostasCorretas) {
    const respostaElemento = document.getElementById(`respostaQuiz_${perguntaId}`);
    const botoes = document.querySelectorAll(`#pergunta_${perguntaId} button`);

    respostaElemento.textContent = "";
    respostaElemento.classList.remove("errado");
    respostaElemento.dataset.respondido = "false";

    botoes.forEach(btn => btn.disabled = false);
  }
}
