const form = document.getElementById("projectForm");
const projectList = document.getElementById("projectList");
const nameInput = document.getElementById("projectName");
const statusInput = document.getElementById("projectStatus");

let editingProject = null;

form.addEventListener("submit", function(e) {
  e.preventDefault();
  
  const name = nameInput.value;
  const status = statusInput.value;

  if (editingProject) {
    editingProject.querySelector("h3").textContent = name;
    editingProject.querySelector(".status").textContent = `Status: ${status}`;
    editingProject = null;
    form.reset();
    form.querySelector("button").textContent = "Adicionar Projeto";
    return;
  }

  const projectEl = document.createElement("div");
  projectEl.classList.add("project");
  projectEl.innerHTML = `
    <h3>${name}</h3>
    <p class="status">Status: ${status}</p>
    <div class="actions">
      <button class="edit">✏️ Editar</button>
      <button class="delete">🗑️ Excluir</button>
    </div>
  `;

  const editBtn = projectEl.querySelector(".edit");
  const deleteBtn = projectEl.querySelector(".delete");

  editBtn.addEventListener("click", () => {
    nameInput.value = name;
    statusInput.value = status;
    editingProject = projectEl;
    form.querySelector("button").textContent = "Salvar Alterações";
  });

  deleteBtn.addEventListener("click", () => {
    if (confirm("Tem certeza que deseja excluir este projeto?")) {
      projectEl.remove();
      if (editingProject === projectEl) {
        form.reset();
        form.querySelector("button").textContent = "Adicionar Projeto";
        editingProject = null;
      }
    }
  });

  projectList.appendChild(projectEl);
  form.reset();
});
