function showTab(tabId) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
  }
  
  const cities = [
    { name: "São Paulo", timeZone: "America/Sao_Paulo" },
    { name: "Nova York", timeZone: "America/New_York" },
    { name: "Londres", timeZone: "Europe/London" },
    { name: "Tóquio", timeZone: "Asia/Tokyo" }
  ];
  
  function updateWorldClock() {
    const container = document.getElementById('worldClock');
    container.innerHTML = '';
    cities.forEach(city => {
      const now = new Date().toLocaleTimeString('pt-BR', {
        timeZone: city.timeZone,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      const div = document.createElement('div');
      div.innerHTML = `<strong>${city.name}</strong><br>${now}`;
      container.appendChild(div);
    });
  }
  setInterval(updateWorldClock, 1000);
  updateWorldClock();
  
  let swStart = null, swElapsed = 0, swInterval = null, swLaps = [];
  
  function updateSWDisplay(ms) {
    const d = new Date(ms);
    const h = String(d.getUTCHours()).padStart(2, '0');
    const m = String(d.getUTCMinutes()).padStart(2, '0');
    const s = String(d.getUTCSeconds()).padStart(2, '0');
    const msPart = String(d.getUTCMilliseconds()).padStart(3, '0');
    document.getElementById('swDisplay').textContent = `${h}:${m}:${s}.${msPart}`;
  }
  
  function startStopwatch() {
    if (swInterval) return;
    swStart = performance.now() - swElapsed;
    swInterval = setInterval(() => {
      swElapsed = performance.now() - swStart;
      updateSWDisplay(swElapsed);
    }, 10);
  }
  
  function pauseStopwatch() {
    clearInterval(swInterval);
    swInterval = null;
  }
  
  function resetStopwatch() {
    pauseStopwatch();
    swElapsed = 0;
    swLaps = [];
    updateSWDisplay(0);
    document.getElementById('swLaps').innerHTML = '';
  }
  
  function lapStopwatch() {
    if (!swInterval) return;
    swLaps.push(swElapsed);
    const div = document.createElement('div');
    div.textContent = `Volta ${swLaps.length}: ${document.getElementById('swDisplay').textContent}`;
    document.getElementById('swLaps').prepend(div);
  }
  
  let timerTimeout = null;
  
  function startTimer() {
    resetTimer();
    const minutes = parseInt(document.getElementById('timerMinutes').value) || 0;
    const seconds = parseInt(document.getElementById('timerSeconds').value) || 0;
    let total = minutes * 60 + seconds;
    if (total <= 0) return;
    const display = document.getElementById('timerDisplay');
  
    timerTimeout = setInterval(() => {
      if (total <= 0) {
        clearInterval(timerTimeout);
        display.textContent = "00:00";
        document.getElementById('beep').play();
      } else {
        total--;
        const mm = String(Math.floor(total / 60)).padStart(2, '0');
        const ss = String(total % 60).padStart(2, '0');
        display.textContent = `${mm}:${ss}`;
      }
    }, 1000);
  }
  
  function resetTimer() {
    clearInterval(timerTimeout);
    document.getElementById('timerDisplay').textContent = "00:00";
  }
  
  let alarmTime = null;
  let alarmInterval = null;
  
  function setAlarm() {
    const timeInput = document.getElementById('alarmTime').value;
    if (!timeInput) return;
    alarmTime = timeInput;
    document.getElementById('alarmStatus').textContent = `⏰ Alarme definido para ${alarmTime}`;
    if (alarmInterval) clearInterval(alarmInterval);
  
    alarmInterval = setInterval(() => {
      const now = new Date();
      const nowTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      if (nowTime === alarmTime) {
        document.getElementById('beep').play();
        clearInterval(alarmInterval);
        document.getElementById('alarmStatus').textContent = `🎉 Alarme disparado às ${alarmTime}!`;
      }
    }, 1000);
  }
  
  function clearAlarm() {
    clearInterval(alarmInterval);
    alarmInterval = null;
    document.getElementById('alarmStatus').textContent = "Nenhum alarme definido.";
  }

  function calcularIdade() {
    const idadeHumana = document.getElementById('idadeHumana').value;
    const resultado = document.getElementById('resultado');
  
    if (idadeHumana === '' || idadeHumana < 0) {
      resultado.textContent = 'Por favor, insira uma idade válida 🐕';
      return;
    }
  
    let idadeCanina;
    if (idadeHumana <= 2) {
      idadeCanina = idadeHumana * 10.5;
    } else {
      idadeCanina = 21 + (idadeHumana - 2) * 4;
    }
  
    resultado.textContent = `Seu doguinho tem aproximadamente ${idadeCanina.toFixed(1)} anos caninos! 🐾`;
  }
  

  function gerarSenha() {
    const comprimento = parseInt(document.getElementById('comprimento').value);
    const resultado = document.getElementById('senhaGerada');
  
    if (isNaN(comprimento) || comprimento < 4) {
      resultado.textContent = 'Por favor, escolha pelo menos 4 caracteres 🌸';
      return;
    }
  
    const caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*()_+=[]{}';
    let senha = '';
  
    for (let i = 0; i < comprimento; i++) {
      const aleatorio = Math.floor(Math.random() * caracteres.length);
      senha += caracteres[aleatorio];
    }
  
    resultado.textContent = `✨ Sua senha: ${senha}`;
  }
  

  function adicionarAoMercado(elemento) {
    const mercado = document.getElementById('mercado');
  
    const itemNovo = document.createElement('li');
    itemNovo.textContent = elemento.textContent;
  
    // Salvar categoria original
    const categoriaOriginal = encontrarCategoria(elemento);
    itemNovo.dataset.categoria = categoriaOriginal;
  
    // Clique para ir ao carrinho
    itemNovo.onclick = () => adicionarAoCarrinho(itemNovo);
  
    mercado.appendChild(itemNovo);
    elemento.remove(); // Remove da lista original
  }
  function adicionarAoCarrinho(elemento) {
    const carrinho = document.getElementById('carrinho');
    const itemTexto = elemento.textContent.trim();
    const categoriaOriginal = elemento.dataset.categoria;
  
    const itemNovo = document.createElement('li');
    itemNovo.textContent = `${itemTexto} ✅`;
  
    const botaoRemover = document.createElement('button');
    botaoRemover.textContent = '❌';
    botaoRemover.style.marginLeft = '10px';
    botaoRemover.onclick = () => voltarParaCategoria(itemNovo, itemTexto, categoriaOriginal);
  
    itemNovo.appendChild(botaoRemover);
    carrinho.appendChild(itemNovo);
  
    elemento.remove();
  }
  function voltarParaCategoria(elemento, texto, categoria) {
    const todasCategorias = document.querySelectorAll('.categoria');
    for (let cat of todasCategorias) {
      const titulo = cat.querySelector('h2').textContent.replace(/[^a-zA-ZÀ-ÿ ]/g, '').trim();
      if (titulo === categoria) {
        const li = document.createElement('li');
        li.textContent = texto.replace('✅', '').trim();
        li.onclick = () => toggleItem(li);
        cat.querySelector('ul').appendChild(li);
        break;
      }
    }
    elemento.remove();
  }
  function encontrarCategoria(elemento) {
    const categoria = elemento.closest('.categoria');
    if (categoria) {
      return categoria.querySelector('h2').textContent.replace(/[^a-zA-ZÀ-ÿ ]/g, '').trim();
    }
    return 'Outros';
  }
        