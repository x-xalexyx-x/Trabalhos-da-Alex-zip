const canvas = document.getElementById("pong");
const ctx = canvas.getContext("2d");

// Dimensões das raquetes
const paddleHeight = 100;
const paddleWidth = 10;

// Jogadores
let player1 = { y: 150, score: 0 };
let player2 = { y: 150, score: 0 };

// Velocidade constante
const initialSpeed = 4;

// Bola
let ball = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  radius: 8,
  speedX: initialSpeed,
  speedY: initialSpeed
};

// Controle de teclas
let keys = {};
let gameRunning = true;

// Eventos de teclado
document.addEventListener("keydown", e => keys[e.key] = true);
document.addEventListener("keyup", e => keys[e.key] = false);

// Funções de desenho
function drawRect(x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function drawCircle(x, y, r, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

function drawText(text, x, y) {
  ctx.fillStyle = "#fff";
  ctx.font = "30px Arial";
  ctx.fillText(text, x, y);
}

// Reiniciar a bola no centro com velocidade padrão
function resetBall() {
  ball.x = canvas.width / 2;
  ball.y = canvas.height / 2;

  const dirX = Math.random() > 0.5 ? 1 : -1;
  const dirY = Math.random() > 0.5 ? 1 : -1;

  ball.speedX = initialSpeed * dirX;
  ball.speedY = initialSpeed * dirY;
}

// Exibe a tela de vencedor
function showWinner(winner) {
  gameRunning = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawText(`Parabéns ${winner}!`, canvas.width / 2 - 120, canvas.height / 2);
}

// Loop principal do jogo
function gameLoop() {
  if (!gameRunning) return;

  // Movimento dos jogadores
  if (keys["w"] && player1.y > 0) player1.y -= 6;
  if (keys["s"] && player1.y + paddleHeight < canvas.height) player1.y += 6;
  if (keys["ArrowUp"] && player2.y > 0) player2.y -= 6;
  if (keys["ArrowDown"] && player2.y + paddleHeight < canvas.height) player2.y += 6;

  // Movimento da bola
  ball.x += ball.speedX;
  ball.y += ball.speedY;

  // Rebater teto e chão
  if (ball.y - ball.radius < 0 || ball.y + ball.radius > canvas.height) {
    ball.speedY *= -1;
  }

  // Colisão com jogador 1
  if (
    ball.x - ball.radius <= paddleWidth &&
    ball.y > player1.y &&
    ball.y < player1.y + paddleHeight
  ) {
    ball.speedX = Math.abs(initialSpeed);
  }

  // Colisão com jogador 2
  if (
    ball.x + ball.radius >= canvas.width - paddleWidth &&
    ball.y > player2.y &&
    ball.y < player2.y + paddleHeight
  ) {
    ball.speedX = -Math.abs(initialSpeed);
  }

  // Pontuação
  if (ball.x < 0) {
    player2.score++;
    if (player2.score >= 10) return showWinner("Jogador 2");
    resetBall();
  }

  if (ball.x > canvas.width) {
    player1.score++;
    if (player1.score >= 10) return showWinner("Jogador 1");
    resetBall();
  }

  // Garante velocidade constante
  ball.speedX = Math.sign(ball.speedX) * initialSpeed;
  ball.speedY = Math.sign(ball.speedY) * initialSpeed;

  // Desenhar
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawRect(0, player1.y, paddleWidth, paddleHeight, "white");
  drawRect(canvas.width - paddleWidth, player2.y, paddleWidth, paddleHeight, "white");
  drawCircle(ball.x, ball.y, ball.radius, "white");
  drawText(player1.score, canvas.width / 4, 50);
  drawText(player2.score, canvas.width * 3 / 4, 50);

  requestAnimationFrame(gameLoop);
}

gameLoop();
